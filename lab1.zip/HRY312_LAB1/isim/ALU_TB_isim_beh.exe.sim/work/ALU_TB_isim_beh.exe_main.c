/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

#include "xsi.h"

struct XSI_INFO xsi_info;

char *IEEE_P_2592010699;
char *STD_STANDARD;


int main(int argc, char **argv)
{
    xsi_init_design(argc, argv);
    xsi_register_info(&xsi_info);

    xsi_register_min_prec_unit(-12);
    ieee_p_2592010699_init();
    work_a_3798783386_3212880686_init();
    work_a_1130988942_1181938964_init();
    work_a_4026006458_1033399337_init();
    work_a_4279227585_3212880686_init();
    work_a_2800452134_1181938964_init();
    work_a_3558894211_1181938964_init();
    work_a_0915988124_3212880686_init();
    work_a_1821943073_3212880686_init();
    work_a_3373647807_3212880686_init();
    work_a_2539152452_3212880686_init();
    work_a_0824830020_3212880686_init();
    work_a_2745383001_3212880686_init();
    work_a_1256354733_3212880686_init();
    work_a_3193113484_3212880686_init();
    work_a_0495498285_3212880686_init();
    work_a_0832606739_1181938964_init();
    work_a_2598182923_2372691052_init();


    xsi_register_tops("work_a_2598182923_2372691052");

    IEEE_P_2592010699 = xsi_get_engine_memory("ieee_p_2592010699");
    xsi_register_ieee_std_logic_1164(IEEE_P_2592010699);
    STD_STANDARD = xsi_get_engine_memory("std_standard");

    return xsi_run_simulation(argc, argv);

}
